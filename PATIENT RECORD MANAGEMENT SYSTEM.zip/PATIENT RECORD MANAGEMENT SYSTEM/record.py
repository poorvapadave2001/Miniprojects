from tkinter import*
from PIL import Image,ImageTk
from tkinter import ttk,messagebox 
import pymysql

class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("PATIENT MEDICAL RECORD WINDOW")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="white")
        #bg image
        self.bg=ImageTk.PhotoImage(file="images/medical.jpeg")
        bg=Label(self.root,image=self.bg).place(x=0,y=0,relwidth=1,relheight=1)
        
        #left image
        self.left=ImageTk.PhotoImage(file="images/logo.jpg")
        left=Label(self.root,image=self.left).place(x=80,y=100,width=400,height=500)
        
        #Register Frame
        frame1=Frame(self.root,bg="grey")
        frame1.place(x=480,y=100,width=700,height=500)
        
        title=Label(frame1,text="PATEINT MEDICAL RECORD",font=("times new roman",20,"bold"),bg="white",fg="black").place(x=50,y=30)
        
        #---------------------row1
        
        f_name=Label(frame1,text="First Name",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=50,y=100)
        self.txt_fname=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_fname.place(x=50,y=130,width=250)
        
        l_name=Label(frame1,text="Last Name",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=370,y=100)
        self.txt_lname=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_lname.place(x=370,y=130,width=250)
        #--------------------------------row2
        
        contact=Label(frame1,text="Contact No.",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=50,y=170)
        self.txt_contact=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_contact.place(x=50,y=200,width=250)
        
        email=Label(frame1,text="Email",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=370,y=170)
        self.txt_email=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_email.place(x=370,y=200,width=250)
        #---------------row3
        
        sym=Label(frame1,text="Symptoms",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=50,y=240)
        self.txt_sym=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_sym.place(x=50,y=270,width=250)
        
        meds=Label(frame1,text="Medications Given",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=370,y=240)
        self.txt_meds=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_meds.place(x=370,y=270,width=250)
        #---------------row4
        
        gender=Label(frame1,text="Gender",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=50,y=310)
        
        password=Label(frame1,text="Password",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=370,y=310)
        self.txt_password=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_password.place(x=370,y=340,width=250)
        
        self.cmb_gender=ttk.Combobox(frame1,font=("times new roman",13),state='readonly',justify=CENTER)
        self.cmb_gender['values']=("Select","Male","Female","other")
        self.cmb_gender.place(x=50,y=340,width=250)
        self.cmb_gender.current(0)
        
         #--------------------------------row2
        
        
        cpass=Label(frame1,text="Confirm Password",font=("times new roman",15,"bold"),bg="grey",fg="black").place(x=50,y=380)
        self.txt_cpass=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_cpass.place(x=50,y=410,width=250)
        #-------------------terms
        
        self.var_chk=IntVar()
        chk=Checkbutton(frame1,text="I agree the Terms & Conditions",variable=self.var_chk,onvalue=1,offvalue=0,bg="white",font=("times new roman",12)).place(x=370,y=410)
        
        self.btn_img=ImageTk.PhotoImage(file="images/submit.png")
        btn_register=Button(frame1,image=self.btn_img,bd=0,cursor="hand2",command=self.register_data).place(x=370,y=450)
        
        btn_login=Button(self.root,text="SignIn",bd=0,cursor="hand2",command=self.sign_in_window).place(x=570,y=555,width=180)
    
    def register_data(self):
        if self.txt_fname.get()=="" or self.txt_cpass.get()=="" or self.txt_email.get()=="" or self.cmb_gender.get()=="Select" or self.txt_sym.get()=="" or self.txt_sym.get()=="" or self.txt_password.get()=="" or self.txt_cpass.get()=="":
            messagebox.showerror("Error","ALL FIELDS ARE REQUIRED",parent=self.root)
        elif self.txt_password.get()!=self.txt_cpass.get():
            messagebox.showerror("Error","PASSWORD NOT MATCHED!",parent=self.root)
        elif self.var_chk.get()==0:
            messagebox.showerror("Error","PLEASE AGREE OUR TERMS",parent=self.root)
        else:
            try:
                con=pymysql.connect(host="localhost",user="root",password="",database="patient")
                cur=con.cursor()
                cur.execute("insert into patientdata (f_name,l_name,contact,email,sym,meds,gender,password) values(%s,%s,%s,%s,%s,%s,%s,%s)",
                            (self.txt_fname.get(),
                             self.txt_lname.get(),
                             self.txt_contact.get(),
                             self.txt_email.get(),
                             self.txt_sym.get(),
                             self.txt_meds.get(),
                             self.cmb_gender.get(),
                             self.txt_password.get()
                            ))
                
                con.commit()   
                con.close()         
                messagebox.showinfo("Success","Record Saved sucessfully!",parent=self.root)                
            except Exception as es:
                messagebox.showerror("Error",f"ERROR DUE TO: {str(es)}",parent=self.root)
            
            
            
            # messagebox.showinfo("Success","Record Saved sucessfully!",parent=self.root)
                 
              #self.txt_lname.get(),
              #self.txt_contact.get(),
              #self.txt_email.get(),
              #self.txt_sym.get(),
              #self.txt_meds.get(),
              #self.cmb_gender.get(),
              #self.txt_password.get(),
              #self.txt_cpass.get())
        
    def sign_in_window(self):
        self.new_window = Toplevel(self.root)
        self.app = SignIn(self.new_window)

class SignIn:
    def __init__(self, root):
        self.root = root
        self.root.title("Sign In")
        self.root.geometry("500x400+500+150")
        self.root.config(bg="white")

        title = Label(self.root, text="Sign In", font=("times new roman", 20, "bold"), bg="white", fg="black").place(x=180, y=30)

        email = Label(self.root, text="Email", font=("times new roman", 15, "bold"), bg="white", fg="black").place(x=50, y=100)
        self.txt_email = Entry(self.root, font=("times new roman", 15), bg="lightblue")
        self.txt_email.place(x=180, y=100, width=250)

        password = Label(self.root, text="Password", font=("times new roman", 15, "bold"), bg="white", fg="black").place(x=50, y=150)
        self.txt_password = Entry(self.root, font=("times new roman", 15), bg="lightblue", show='*')
        self.txt_password.place(x=180, y=150, width=250)

        btn_login = Button(self.root, text="Login", font=("times new roman", 15, "bold"), cursor="hand2", command=self.login).place(x=180, y=250, width=120)

    def login(self):
        if self.txt_email.get() == "" or self.txt_password.get() == "":
            messagebox.showerror("Error", "All fields are required", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="", database="patient")
                cur = con.cursor()
                cur.execute("select * from patientdata where email=%s and password=%s", (self.txt_email.get(), self.txt_password.get()))
                row = cur.fetchone()
                if row is None:
                    messagebox.showerror("Error", "Invalid Username or Password", parent=self.root)
                else:
                    messagebox.showinfo("Success", "Welcome", parent=self.root)
                    self.root.destroy()
                    root = Tk()
                    obj = Dashboard(root)
                    root.mainloop()
                con.close()
            except Exception as es:
                messagebox.showerror("Error", f"Error due to: {str(es)}", parent=self.root)
                
    def open_dashboard(self):
        self.new_window = Toplevel(self.root)
        self.app = Dashboard(self.new_window)

class Dashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("Patient Dashboard")
        self.root.geometry("1000x500+150+150")
        self.root.config(bg="white")

        title = Label(self.root, text="Patient Record Dashboard", font=("times new roman", 20, "bold"), bg="white", fg="black").place(x=350, y=30)

        # Buttons for Add, Update, Delete, View Records
        btn_add = Button(self.root, text="Add Record", font=("times new roman", 15, "bold"), cursor="hand2", command=self.add_record).place(x=50, y=100, width=200, height=50)
        btn_update = Button(self.root, text="Update Record", font=("times new roman", 15, "bold"), cursor="hand2", command=self.update_record).place(x=300, y=100, width=200, height=50)
        btn_delete = Button(self.root, text="Delete Record", font=("times new roman", 15, "bold"), cursor="hand2", command=self.delete_record).place(x=550, y=100, width=200, height=50)
        btn_view = Button(self.root, text="View Records", font=("times new roman", 15, "bold"), cursor="hand2", command=self.view_records).place(x=800, y=100, width=200, height=50)

    def add_record(self):
        self.new_window = Toplevel(self.root)
        self.app = AddPatient(self.new_window)

    def update_record(self):
        self.new_window = Toplevel(self.root)
        self.app = UpdatePatient(self.new_window)

    def delete_record(self):
        self.new_window = Toplevel(self.root)
        self.app = DeletePatient(self.new_window)

    def view_records(self):
       self.new_window = Toplevel(self.root)
       self.app = ViewRecords(self.new_window)


class AddPatient:
    def __init__(self, root):
        self.root = root
        self.root.title("Add Patient Record")
        self.root.geometry("400x400+500+200")

        title = Label(self.root, text="Add New Patient", font=("times new roman", 20, "bold")).place(x=80, y=20)

        Label(self.root, text="First Name").place(x=50, y=80)
        self.txt_fname = Entry(self.root)
        self.txt_fname.place(x=150, y=80)

        Label(self.root, text="Last Name").place(x=50, y=120)
        self.txt_lname = Entry(self.root)
        self.txt_lname.place(x=150, y=120)

        Label(self.root, text="Contact No.").place(x=50, y=160)
        self.txt_contact = Entry(self.root)
        self.txt_contact.place(x=150, y=160)

        Label(self.root, text="Email").place(x=50, y=200)
        self.txt_email = Entry(self.root)
        self.txt_email.place(x=150, y=200)

        Label(self.root, text="Symptoms").place(x=50, y=240)
        self.txt_sym = Entry(self.root)
        self.txt_sym.place(x=150, y=240)

        Label(self.root, text="Medications").place(x=50, y=280)
        self.txt_meds = Entry(self.root)
        self.txt_meds.place(x=150, y=280)

        Button(self.root, text="Save", command=self.save_record).place(x=150, y=320)

    def save_record(self):
        if self.txt_fname.get() == "" or self.txt_lname.get() == "" or self.txt_contact.get() == "" or self.txt_email.get() == "":
            messagebox.showerror("Error", "All fields are required", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="", database="patient")
                cur = con.cursor()
                cur.execute("INSERT INTO patientdata (f_name, l_name, contact, email, sym, meds) VALUES (%s, %s, %s, %s, %s, %s)",
                            (self.txt_fname.get(), self.txt_lname.get(), self.txt_contact.get(), self.txt_email.get(), self.txt_sym.get(), self.txt_meds.get()))
                con.commit()
                con.close()
                messagebox.showinfo("Success", "Record added successfully!", parent=self.root)
                self.root.destroy()
            except Exception as es:
                messagebox.showerror("Error", f"Error due to: {str(es)}", parent=self.root)


class UpdatePatient:
    def __init__(self, root):
        self.root = root
        self.root.title("Update Patient Record")
        self.root.geometry("400x400+500+200")

        title = Label(self.root, text="Update Patient", font=("times new roman", 20, "bold")).place(x=100, y=20)

        Label(self.root, text="Patient ID").place(x=50, y=80)
        self.txt_pid = Entry(self.root)
        self.txt_pid.place(x=150, y=80)

        Label(self.root, text="First Name").place(x=50, y=120)
        self.txt_fname = Entry(self.root)
        self.txt_fname.place(x=150, y=120)

        Label(self.root, text="Last Name").place(x=50, y=160)
        self.txt_lname = Entry(self.root)
        self.txt_lname.place(x=150, y=160)

        Label(self.root, text="Contact No.").place(x=50, y=200)
        self.txt_contact = Entry(self.root)
        self.txt_contact.place(x=150, y=200)

        Label(self.root, text="Email").place(x=50, y=240)
        self.txt_email = Entry(self.root)
        self.txt_email.place(x=150, y=240)

        Label(self.root, text="Symptoms").place(x=50, y=280)
        self.txt_sym = Entry(self.root)
        self.txt_sym.place(x=150, y=280)

        Button(self.root, text="Update", command=self.update_record).place(x=150, y=320)

    def update_record(self):
        if self.txt_pid.get() == "":
            messagebox.showerror("Error", "Patient ID is required", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="", database="patient")
                cur = con.cursor()
                cur.execute("UPDATE patientdata SET f_name=%s, l_name=%s, contact=%s, email=%s, sym=%s WHERE id=%s",
                            (self.txt_fname.get(), self.txt_lname.get(), self.txt_contact.get(), self.txt_email.get(), self.txt_sym.get(), self.txt_pid.get()))
                con.commit()
                con.close()
                messagebox.showinfo("Success", "Record updated successfully!", parent=self.root)
                self.root.destroy()
            except Exception as es:
                messagebox.showerror("Error", f"Error due to: {str(es)}", parent=self.root)


class DeletePatient:
    def __init__(self, root):
        self.root = root
        self.root.title("Delete Patient Record")
        self.root.geometry("300x200+500+300")

        Label(self.root, text="Enter Patient ID to delete").place(x=50, y=50)
        self.txt_pid = Entry(self.root)
        self.txt_pid.place(x=50, y=80)

        Button(self.root, text="Delete", command=self.delete_record).place(x=100, y=120)

    def delete_record(self):
        if self.txt_pid.get() == "":
            messagebox.showerror("Error", "Patient ID is required", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="", database="patient")
                cur = con.cursor()
                cur.execute("DELETE FROM patientdata WHERE id=%s", (self.txt_pid.get(),))
                con.commit()
                con.close()
                messagebox.showinfo("Success", "Record deleted successfully!", parent=self.root)
                self.root.destroy()
            except Exception as es:
                messagebox.showerror("Error", f"Error due to: {str(es)}", parent=self.root)

class ViewRecords:
    def __init__(self, root):
        self.root = root
        self.root.title("View Patient Records")
        self.root.geometry("800x400+300+150")

        self.records_table = ttk.Treeview(self.root, columns=("id", "f_name", "l_name", "contact", "email", "sym", "meds"))
        self.records_table.heading("id", text="ID")
        self.records_table.heading("f_name", text="First Name")
        self.records_table.heading("l_name", text="Last Name")
        self.records_table.heading("contact", text="Contact")
        self.records_table.heading("email", text="Email")
        self.records_table.heading("sym", text="Symptoms")
        self.records_table.heading("meds", text="Medications")
        self.records_table['show'] = 'headings'

        self.records_table.column("id", width=50)
        self.records_table.column("f_name", width=100)
        self.records_table.column("l_name", width=100)
        self.records_table.column("contact", width=100)
        self.records_table.column("email", width=150)
        self.records_table.column("sym", width=100)
        self.records_table.column("meds", width=100)

        self.records_table.pack(fill=BOTH, expand=1)

        self.fetch_data()

    def fetch_data(self):
        try:
            con = pymysql.connect(host="localhost", user="root", password="", database="patient")
            cur = con.cursor()
            cur.execute("SELECT * FROM patientdata")
            rows = cur.fetchall()
            if rows:
                for row in rows:
                    self.records_table.insert('', END, values=row)
            con.close()
        except Exception as es:
            messagebox.showerror("Error", f"Error due to: {str(es)}", parent=self.root)
            

root = Tk()
obj = Register(root)
root.mainloop()

    
