import requests
from bs4 import BeautifulSoup
import tkinter as tk
from tkinter import ttk
import webbrowser

# Function to extract news headlines from a given URL
def extract_headlines(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')

    # Adjust selectors based on the specific structure of the news websites
    headline_elements = soup.find_all('h2', class_='title')  # Example selector for Hindustan Times
    # headline_elements = soup.find_all('h3', class_='news-card__title')  # Example selector for India News

    headlines = []
    for element in headline_elements:
        headline = element.text.strip()
        headlines.append(headline)

    return headlines

# Function to create the GUI
def create_gui():
    root = tk.Tk()
    root.title("News Aggregator")

    # Create labels and entry fields for URLs
    url_label2 = tk.Label(root, text="India News URL:")
    url_label2.grid(row=1, column=0)
    url_entry2 = tk.Entry(root, width=50)
    url_entry2.grid(row=1, column=1)

    # Create a button to fetch and display headlines
    def fetch_headlines():
        url2 = url_entry2.get()

        if not url2:
            headlines_text.insert(tk.END, "Please enter URL.\n")
            return

        try:
            headlines2 = extract_headlines(url2)

            headlines_text.delete(1.0, tk.END)
            headlines_text.insert(tk.END, "\nIndia News Headlines:\n")
            for headline in headlines2:
                headlines_text.insert(tk.END, f"- {headline}\n")
        except Exception as e:
            headlines_text.insert(tk.END, f"Error: {e}\n")

    # Create a button to fetch and display headlines
    fetch_button = tk.Button(root, text="Fetch Headlines", command=fetch_headlines)
    fetch_button.grid(row=2, column=0, columnspan=2)

    # Create a text widget to display headlines
    headlines_text = tk.Text(root, height=15, width=80)
    headlines_text.grid(row=3, column=0, columnspan=2)

    root.mainloop()

# Start the GUI
create_gui()